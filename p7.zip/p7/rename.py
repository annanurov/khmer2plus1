import os
for filename in os.listdir("."):
#for f in files:
  x = filename.find("-slice_")
  if x>-1:
    newname = filename[:x+1] + "p7" + filename[x+6:]
    os.rename(filename, newname)

"""resized-p1_15_49"""
